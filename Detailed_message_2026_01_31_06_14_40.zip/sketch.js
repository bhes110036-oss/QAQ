let particles = [];
let colorHue = 0;

function setup() {
  // 核心：創建一個與瀏覽器視窗同寬高的畫布
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100, 100);
  background(0);
}

function draw() {
  // 微弱的透明背景，創造長拖尾效果
  background(0, 0, 0, 8);

  // 同時支援滑鼠與觸控位置
  let posX = mouseX;
  let posY = mouseY;

  // 只有在畫布內移動時才產生粒子
  if (posX > 0 && posY > 0) {
    for (let i = 0; i < 2; i++) {
      particles.push(new Particle(posX, posY));
    }
  }

  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].show();
    if (particles[i].isFinished()) {
      particles.splice(i, 1);
    }
  }
}

// 響應式關鍵：當瀏覽器視窗大小改變時，自動調整畫布
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  background(0); // 縮放時清空一次背景避免拉伸殘影
}

class Particle {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D().mult(random(2, 5));
    this.acc = createVector(0, 0);
    this.life = 255;
    this.h = (frameCount * 0.5) % 360; // 隨時間緩慢循環的色相
  }

  update() {
    this.pos.add(this.vel);
    this.life -= 4; // 控制消失速度
  }

  show() {
    strokeWeight(random(1, 3));
    stroke(this.h, 80, 100, this.life / 2.5);
    // 畫線條而不是圓點，增加絲綢感
    line(this.pos.x, this.pos.y, this.pos.x - this.vel.x * 2, this.pos.y - this.vel.y * 2);
  }

  isFinished() {
    return this.life < 0;
  }
}